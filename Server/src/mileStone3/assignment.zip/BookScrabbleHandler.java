package test;


public class BookScrabbleHandler {
}
